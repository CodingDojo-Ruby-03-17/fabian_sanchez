class AddDojoIDtoNinja < ActiveRecord::Migration
  def change
  end
end
